/*
 * File:   main.c
 * Author: CARLOS ANDR�S ESCOBAR M�NDEZ
 * USO DE SENSOR ULTRAS�NICO
 * Created on 21 DE AGOSTO DEL 2023
 */
//*****************************************************************************
// Palabra de configuraci?n
//*****************************************************************************
// CONFIG1
#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // RE3/MCLR pin function select bit (RE3/MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal/External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

//*****************************************************************************
// Definici?n e importaci?n de librer?as
//*****************************************************************************
#include <stdint.h>
#include <pic16f887.h>
#include "I2C.h"
#include <xc.h>
//*****************************************************************************
// Definici?n de variables
//*****************************************************************************
#define _XTAL_FREQ 8000000
#define TRIGGER_PIN RA0
#define ECHO_PIN RA1
#define LDR_THRESHOLD 10 // Valor para el 5% del rango de 0-255
uint8_t z;
uint8_t servoPosition = 0;
uint8_t dato, estado_puerta=0;


//*****************************************************************************
// Definici?n de funciones para que se puedan colocar despu?s del main de lo 
// contrario hay que colocarlos todas las funciones antes del main
//*****************************************************************************
void setup(void);
void triggerPulse(void);
//*****************************************************************************
// C?digo de Interrupci?n 
//*****************************************************************************
void __interrupt() isr(void){
   if(PIR1bits.SSPIF == 1){ 

        SSPCONbits.CKP = 0;
       
        if ((SSPCONbits.SSPOV) || (SSPCONbits.WCOL)){
            z = SSPBUF;                 // Read the previous value to clear the buffer
            SSPCONbits.SSPOV = 0;       // Clear the overflow flag
            SSPCONbits.WCOL = 0;        // Clear the collision bit
            SSPCONbits.CKP = 1;         // Enables SCL (Clock)
        }

        if(!SSPSTATbits.D_nA && !SSPSTATbits.R_nW) {
            //__delay_us(7);
            z = SSPBUF;                 // Lectura del SSBUF para limpiar el buffer y la bandera BF
            //__delay_us(2);
            PIR1bits.SSPIF = 0;         // Limpia bandera de interrupci?n recepci?n/transmisi?n SSP
            SSPCONbits.CKP = 1;         // Habilita entrada de pulsos de reloj SCL
            while(!SSPSTATbits.BF);     // Esperar a que la recepci?n se complete
            dato = SSPBUF;             // Guardar en el PORTD el valor del buffer de recepci?n
            __delay_us(250);
            
        }else if(!SSPSTATbits.D_nA && SSPSTATbits.R_nW){
            z = SSPBUF;
            BF = 0;
            SSPBUF = estado_puerta;
            SSPCONbits.CKP = 1;
            __delay_us(250);
            while(SSPSTATbits.BF);
        }
       
        PIR1bits.SSPIF = 0;    
    }

    
}
//*****************************************************************************
// Main
//*****************************************************************************
void main(void) {
      setup();
    while (1) {
        triggerPulse(); // Realiza la medici�n de la distancia
        
        // Espera hasta que ECHO_PIN se vuelva alto (inicio del eco)
        while (!ECHO_PIN);
        
        // Inicia el Timer1 para medir el tiempo del pulso de eco
        TMR1 = 0;
        T1CONbits.TMR1ON = 1;
        
        // Espera hasta que ECHO_PIN se vuelva bajo (fin del eco)
        while (ECHO_PIN);
        
        // Detiene el Timer1 y calcula la distancia en cm
        T1CONbits.TMR1ON = 0;
        unsigned int distance = TMR1 * 0.0343 / 2;
        
        // Desactiva las interrupciones para evitar problemas durante la actualizaci�n del servo
        INTCONbits.GIE = 0;
        
        // Control del servo en funci�n de la distancia
        if (distance <= 10) {
            // Si la distancia es 10 cm o menos, posici�n del servo: -90 grados
            servoPosition = 90;

            
           // __delay_us(100);
        } else if (distance <= 50) {
            // Si la distancia es menor o igual a 50 cm, posici�n del servo: 0 grados
            //servoPosition = 0;
            servoPosition = 250; // Otra posici�n que corresponda a 0 grados
           
           // __delay_us(100);
        } else {
            // Si la distancia es mayor a 50 cm, posici�n del servo: 90 grados
            servoPosition = 250;

           
           // __delay_us(100);
        }
        
        // Aplica la posici�n del servo
        CCPR1L = servoPosition;
        
        // Activa las interrupciones nuevamente
        INTCONbits.GIE = 1;
        
        if (CCPR1L == 90)
        {
            estado_puerta = 0;
        }
        else if(CCPR1L == 250)
        {
            estado_puerta = 1;
        }
        // Peque�a espera antes de la pr�xima medici�n
        __delay_ms(100);
    }
    return;
}
//*****************************************************************************
// Funci?n de Inicializaci?n
//*****************************************************************************
void setup(void){
    ANSEL = 0b00000000; // Habilitar el pin AN0 para el sensor ultrasonico
    ANSELH = 0;
    
    TRISA = 0b00000010; // Configurar RA0 como salida y RA1 como entrada
    TRISE = 0;
    
    PORTA = 0;
    PORTE = 0;
    
    
     //CONFIGURACI�N DEL OSCILADOR
    OSCCONbits.IRCF = 0b0111; //FRECUENICA DE 8 MHZ
    OSCCONbits.SCS = 1; //RELOJ INTERNO PARA EL FUNCIONAMIENTO
    
    //CONFIGURACI�N DE LAS INTERRUPCIONES
    INTCONbits.GIE = 1; //BANDERA GLOBAL HABILITADA
    INTCONbits.PEIE = 1; //INERRUPCIONES PERIF�RICAS HABILITADAS

    //configuraci�n del PWM

    PR2 = 255; //valor del PWM Para una frecuencia m�ximca
    CCP1CONbits.P1M = 0; //CONFIGURA EL CANAL CCP1 COMO PWM 
    CCP1CONbits.CCP1M = 0b1100; // MODO DE OPERACI�N COMO PWM
    CCPR1L = 0x0f; // VALOR INICIAL DEL CCP1
    CCP1CONbits.DC1B = 0; //VALOR INICIAL DEL BIT MENOS SIGNIFICATIVO DEL CANAL CCP1

    
    //CONFIGURACI�N DEL TIMER 2
    PIR1bits.TMR2IF = 0; //bandera en 0
    T2CONbits.T2CKPS = 0b11; //1:16 prescaler
    T2CONbits.TMR2ON = 1;//se enciende el timer 2
    while(PIR1bits.TMR2IF == 0); //primer ciclo del timer 2
    PIR1bits.TMR2IF = 0;// se limpia la bandera del timer 2
    TRISCbits.TRISC2 = 0; // salida del PWM
    //FIN DE LA CONFIGURACI�N DEL TIMER 2
    
    // Configuraci�n del Timer1
    T1CONbits.T1CKPS = 0b11; // Prescaler 1:8
    T1CONbits.TMR1CS = 0;    // Fuente de reloj: Fosc/4
    T1CONbits.TMR1ON = 0;    // Apagar el Timer1 inicialmente
    
    //CCPR1L = 255;
    
    I2C_Slave_Init(0x60);   
    return;
}

void triggerPulse(void) {
    TRIGGER_PIN = 1;
    __delay_us(10);
    TRIGGER_PIN = 0;
}
