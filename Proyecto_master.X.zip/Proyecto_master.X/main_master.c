
/*
 * File:   main.c
 * Author: CARLOS ANDR�S ESCOBAR M�NDEZ
 * MASTER 
 * Created on 21 DE AGOSTO DEL 2023
 */
//*****************************************************************************
// Palabra de configuraci?n
//*****************************************************************************
// CONFIG1
#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // RE3/MCLR pin function select bit (RE3/MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal/External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

// Definici?n e importaci?n de librer?as
//*****************************************************************************
#include <stdint.h>
#include <stdio.h>
#include <pic16f887.h>
#include "I2C.h"
#include <xc.h>
#include "LCD.h"
//*****************************************************************************
// Definici?n de variables
//*****************************************************************************
#define _XTAL_FREQ 8000000
#define RS RE0
#define EN RE1
uint8_t flag_fr=0, flag_ut = 0;
char sec;
char min;
char hour;
char hora[9];
char captura[9]; // Cambia la variable captura a un arreglo
int cont=0;
        
//*****************************************************************************
// Definici?n de funciones para que se puedan colocar despu?s del main de lo 
// contrario hay que colocarlos todas las funciones antes del main
//*****************************************************************************
void setup(void);
uint8_t bcd_to_decimal(uint8_t bdc); //funcion de conversion

//*****************************************************************************
// Main


//*****************************************************************************
void main(void) {
    setup();
    Lcd_Init();
    
    while(1){
        I2C_Master_Start();
        I2C_Master_Write(0x51);
        flag_fr = I2C_Master_Read(0); //RECIBE EL VALOR DEL ADC1
        I2C_Master_Stop();
        __delay_ms(200);
        
        I2C_Master_Start();
        I2C_Master_Write(0x61);
        flag_ut = I2C_Master_Read(0); //RECIBE EL VALOR DEL ADC1
        I2C_Master_Stop();
        __delay_ms(200);
        
        Lcd_Clear();
        Lcd_Set_Cursor(1,1);
        Lcd_Write_String("L:");//MUESTRA EL PAR�METRO DE LIGHT
           
        Lcd_Set_Cursor(1,3);
        if (flag_fr == 1)
            Lcd_Write_String("ON");//SI LA FOTORESISTENCIA ENV�A EL VALOR DE 1, LA LCD DICE QUE LA LUZ EST� ENCENDIDA
        else  if(flag_fr == 0)
            Lcd_Write_String("OFF");//SI LA FOTORESISTENCIA ENV�A EL VALOR DE 0, LA LCD DICE QUE LA LUZ EST� APAGADA
        
        
        Lcd_Set_Cursor(2,1);
        Lcd_Write_String("D:");
        
        Lcd_Set_Cursor(2,3);
        if (flag_ut == 1)
            Lcd_Write_String("OPEN");//SI EL SENSOR ULTRAS�NICO ENV�A EL VALOR DE 1, LA LCD DICE QUE LA PUERTA EST� ABIERTA
        else
            Lcd_Write_String("CLOSE");//SI EL SENSOR ULTRAS�NICO ENV�A EL VALOR DE 0, LA LCD DICE QUE LA PUERTA EST� CERRADA
        
        
        PORTBbits.RB0 = flag_ut;
        PORTBbits.RB1 = flag_fr;
       // PORTBbits.RB2=1;
        
        /*~~~~~~~~~~~~~~RTC~~~~~~~~~~~~~~*/
        //segundos
        I2C_Master_Start();          // Iniciar el I2C
        I2C_Master_Write(0xD0);      // Escribir la direccion del RTC para escritura
        I2C_Master_Write(0x00);      // Seleccionar registro de segundos
        I2C_Master_RepeatedStart();  // Reiniciar el I2C
        I2C_Master_Write(0xD1);      // Escribir la direccion del RTC para lectura
        sec = I2C_Master_Read(0);
        I2C_Master_Stop();
        Lcd_Set_Cursor(1,11);
       
        
        //minutos
        I2C_Master_Start();          // Iniciar el I2C
        I2C_Master_Write(0xD0);      // Escribir la direccion del RTC para escritura
        I2C_Master_Write(0x01);      // Seleccionar registro de minutos
        I2C_Master_RepeatedStart();  // Reiniciar el I2C
        I2C_Master_Write(0xD1);      // Escribir la direccion del RTC para lectura
        min = I2C_Master_Read(0);
        I2C_Master_Stop();
     
        
        //horas
        I2C_Master_Start();          // Iniciar el I2C
        I2C_Master_Write(0xD0);      // Escribir la direccion del RTC para escritura
        I2C_Master_Write(0x02);      // Seleccionar registro de hora
        I2C_Master_RepeatedStart();  // Reiniciar el I2C
        I2C_Master_Write(0xD1);      // Escribir la direccion del RTC para lectura
        hour = I2C_Master_Read(0);
        I2C_Master_Stop();
     
        
        uint8_t seconds_decimal = bcd_to_decimal(sec);
        uint8_t minutes_decimal = bcd_to_decimal(min);
        uint8_t hours_decimal = bcd_to_decimal(hour);
        sprintf(hora,"%d:%d:%d",hours_decimal,minutes_decimal ,seconds_decimal);//REALIZA UNA UNI�N DE LAS HORAS, MINUTOS Y SEGUNDOS PARA MOSTRARSE EN LA LCD
        
        if (flag_ut == 0) {
                for (int i = 0; i < 9; i++) {
                    captura[i] = hora[i]; // Copiar cada car�cter de hora a captura
                }
            
        }
        
        Lcd_Set_Cursor(1,8);
        Lcd_Write_String(hora);
        Lcd_Set_Cursor(2,8);
        Lcd_Write_String(captura);
        
        
        
        
        

        
        //char valor_ut = flag_ut + '0';
        //Lcd_Write_Char(valor_ut);

         __delay_ms(200);
        
        //PORTBbits.RB2=1;

    
    }
    return;
}
//*****************************************************************************
// Funci?n de Inicializaci?n
//*****************************************************************************
void setup(void){
    ANSEL = 0;
    ANSELH = 0;
    
    TRISB = 0; 
    TRISD = 0;
    TRISE = 0;
   
    PORTB = 0;
    PORTD = 0;
    PORTE=0;
    
    //CONFIGURACI�N DEL OSCILADOR
    OSCCONbits.IRCF = 0b0111; //FRECUENICA DE 8 MHZ
    OSCCONbits.SCS = 1; //RELOJ INTERNO PARA EL FUNCIONAMIENTO
    
    I2C_Master_Init(100000);        // Inicializar Comuncaci?n I2C
    //ioc_init(0); //habilita el pin 0 del puerto B como entrada
    //ioc_init(1); //habilita el pin 1 del puerto B como entrada
    //ioc_init(2); //habilita el pin 1 del puerto B como entrada
    GIE = 1;
}

//Funciones locales
/*******************************************************************/
uint8_t bcd_to_decimal(uint8_t bcd){
    return ((bcd >> 4) * 10) + (bcd & 0x0F); //FUNC�N PAA CONVERTIR VALORES A DECIMALES
}

